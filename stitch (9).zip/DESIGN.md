# Design System Document: High-End Editorial Gastronomy

## 1. Overview & Creative North Star
**Creative North Star: "The Midnight Sommelier"**

This design system is built to evoke the atmosphere of an exclusive, high-end restaurant after dark—where the lighting is low, the focus is intense, and every detail is intentional. We are moving away from the "template" look of a standard landing page. Instead, we embrace **Editorial Gilded Minimalism**. 

The goal is to treat the screen as a luxury magazine spread. We break the rigid grid through intentional asymmetry, using large-scale typography as a structural element and "pools of light" (yellow accents) to guide the eye. This isn't just a UI; it’s an invitation to a premium sensory experience.

---

## 2. Colors: Light within the Void
Our palette is rooted in deep blacks to create a sense of infinite depth, punctuated by vibrant yellows that mimic candlelight or golden champagne.

- **The "No-Line" Rule:** Under no circumstances are 1px solid borders to be used for sectioning or containment. Boundaries must be defined solely through background color shifts. For example, a "Menu" section using `surface-container-low` should sit directly against a `background` section. The change in tone provides the boundary; the lack of lines provides the luxury.
- **Surface Hierarchy & Nesting:** Treat the UI as layers of fine materials.
    - **Base Layer:** `surface` (#0e0e0e) for the primary page background.
    - **Interaction Layer:** Use `surface-container` (#1a1919) for cards or highlighted blocks.
    - **Lifted Layer:** Use `surface-container-high` (#201f1f) for floating elements like navigation bars or modals.
- **The "Glass & Gradient" Rule:** To avoid a flat, digital feel, apply glassmorphism to floating headers or reservation widgets. Use a background blur (12px–20px) with a semi-transparent `surface-variant`. For primary CTAs, use a subtle radial gradient from `primary` (#ffe484) to `primary-container` (#fdd404) to give the button a "glow" rather than a flat fill.

---

## 3. Typography: The Editorial Voice
We use a high-contrast pairing of an elegant serif and a technical sans-serif to communicate both tradition and modern precision.

- **Display & Headlines (Newsreader):** These are your "Signature" elements. Use `display-lg` for hero statements. Don't be afraid to overlap images with text or use negative letter-spacing (-0.02em) to create a tight, high-fashion look.
- **Titles & Body (Inter):** Inter provides the "Functional" voice. It must remain clean and highly legible. Use `title-md` for dish names and `body-md` for descriptions.
- **Label System:** All `label-md` and `label-sm` text should be set in uppercase with increased letter-spacing (+0.05em) to act as sophisticated markers for categories (e.g., "APPETIZERS," "VINTAGE").

---

## 4. Elevation & Depth: Tonal Layering
In this system, we do not "drop shadows"; we "emit light."

- **The Layering Principle:** Achieve depth by stacking surface tiers. A `surface-container-lowest` card placed on a `surface-container-low` section creates a recessed, "carved-in" look, which feels more architectural and premium than a simple shadow.
- **Ambient Shadows:** When an element must float (like a "Book Now" floating action button), use an extra-diffused shadow: `blur: 40px`, `spread: -5px`, `opacity: 8%`. The shadow color should be a tinted version of the background, never a generic gray.
- **The "Ghost Border" Fallback:** If a container requires more definition for accessibility, use a **Ghost Border**. This is a 1px stroke using the `outline-variant` token at 15% opacity. It should be felt rather than seen.
- **Glassmorphism:** Use `surface-container-highest` at 70% opacity with a `backdrop-filter: blur(16px)` for overlays. This ensures the vibrant food photography is subtly visible through the UI, maintaining the "appetizing" nature of the site.

---

## 5. Components: Minimalist Primitives

- **Buttons:**
    - **Primary:** `primary` background with `on-primary` text. Use `rounded-sm` (0.125rem) for a sharper, more architectural feel. No borders.
    - **Tertiary:** `on-background` text with a `primary` underline that only appears on hover.
- **Cards (The "Plating" Component):**
    - Cards must not have borders or dividers. Separate content using `spacing-6` (2rem) or `spacing-8` (2.75rem). Use high-quality imagery that fills the container or bleeds off the edge of the card.
- **Input Fields:**
    - Use "Underline Only" style for a more sophisticated look. Use `outline-variant` for the bottom stroke. On focus, transition the stroke to `primary`. 
- **Navigation:**
    - A fixed top bar using a glassmorphic `surface-container-low` (80% opacity). Use `label-md` for menu links to maintain an editorial feel.
- **Additional Component: The "Chef's Feature" Reveal:**
    - A custom hover-state component for menu items. When the user hovers over a text-based menu item, a high-resolution "preview image" of the dish fades in at 20% opacity behind the text, or follows the cursor.

---

## 6. Do's and Don'ts

### Do:
- **Do** use generous white space. If you think there is enough space, add one more level from the spacing scale (`spacing-12` or `spacing-16`).
- **Do** use asymmetrical layouts. Place a large `display-lg` heading on the left and a smaller description on the right with a large offset.
- **Do** ensure all food photography is high-contrast and professionally lit to match the "Deep Black" theme.

### Don't:
- **Don't** use 100% opaque white for body text. Use `on-surface-variant` to keep the hierarchy elegant and reduce eye strain against the black background.
- **Don't** use "Standard" Material Design rounded corners. Stick to `sm` (0.125rem) or `none` for a more "Couture" look. Avoid `full` or `xl` except for specific functional icons.
- **Don't** use divider lines between menu items. Use the `spacing-4` scale to create clean, rhythmic separation.
- **Don't** use stock animations. All transitions should be "slow and intentional"—use `cubic-bezier(0.16, 1, 0.3, 1)` for all transforms to mimic a luxury feel.